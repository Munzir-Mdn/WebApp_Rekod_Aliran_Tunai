# Rekod Aliran Tunai — Offline Web App

Aplikasi web ringkas untuk merekod **pendapatan dan perbelanjaan harian** secara offline menggunakan **HTML, CSS dan Vanilla JavaScript**.

Data disimpan terus di dalam `localStorage` browser, jadi aplikasi boleh digunakan tanpa server, database atau sambungan internet selepas fail HTML tersedia pada peranti.

## Ciri-ciri

- Rekod pendapatan dan perbelanjaan harian
- Tambah, edit dan padam transaksi
- Simpan data secara offline menggunakan `localStorage`
- Dashboard jumlah pendapatan, perbelanjaan, baki bersih dan bilangan rekod
- Ringkasan perbelanjaan mengikut catatan
- Ringkasan bulanan
- Carian transaksi
- Filter mengikut bulan dan jenis transaksi
- Eksport rekod ke CSV
- Backup data ke JSON
- Pulihkan data daripada fail JSON
- Responsive untuk desktop dan skrin kecil
- Tiada framework dan tiada backend diperlukan

## Catatan Transaksi

Dropdown catatan yang disediakan:

- `GAJI`
- `MYTNB`
- `MYUNIFI`
- `KAD KREDIT VISA`
- `KAD KREDIT MC`
- `PB VIOS`
- `HOMELOAN`
- `DUIT BELANJA MYWIFE`
- `AEON`
- `BONUS`
- `Lain-lain`

Jika `Lain-lain` dipilih, pengguna boleh memasukkan catatan tambahan.

## Teknologi

| Teknologi | Kegunaan |
|---|---|
| HTML5 | Struktur aplikasi |
| CSS3 | Antara muka dan responsive layout |
| Vanilla JavaScript | Logik aplikasi dan dashboard |
| Web Storage API (`localStorage`) | Penyimpanan data offline |
| JSON | Backup dan restore |
| CSV | Eksport transaksi |

## Cara Menggunakan

1. Clone atau muat turun repository ini.
2. Buka fail `rekod-aliran-tunai-offline.html` menggunakan browser seperti Chrome, Edge atau Firefox.
3. Masukkan tarikh, jenis transaksi, jumlah dan catatan.
4. Tekan **Simpan Rekod**.
5. Rekod akan disimpan dalam `localStorage` browser yang digunakan.
6. Gunakan **Backup JSON** secara berkala untuk membuat salinan data.

Tiada proses installation, `npm install`, database atau web server diperlukan.

## Struktur Projek

```text
rekod-aliran-tunai/
├── rekod-aliran-tunai-offline.html
└── README.md
```

Aplikasi menggunakan pendekatan single-file: HTML, CSS dan JavaScript berada dalam satu fail.

## Penyimpanan Data

Data aplikasi disimpan menggunakan key:

```javascript
const STORAGE_KEY = 'rekod_aliran_tunai_v1';
```

Secara konsep:

```text
Borang Transaksi
       │
       ▼
Vanilla JavaScript
       │
       ▼
localStorage
       │
       ├── Dashboard
       ├── Jadual Transaksi
       ├── Edit / Padam
       ├── Export CSV
       └── Backup JSON
```

## Backup dan Restore

### Backup

Klik **Backup JSON** untuk menghasilkan salinan rekod dalam format `.json`.

### Restore

Klik **Pulih JSON** dan pilih fail backup JSON yang sah.

> [!IMPORTANT]
> `localStorage` bukan cloud storage. Data disimpan pada browser/peranti yang digunakan. Membersihkan site data/browser storage boleh menyebabkan data tempatan hilang. Simpan backup JSON secara berkala.

## Eksport CSV

Butang **Eksport CSV** menghasilkan fail yang boleh dibuka menggunakan aplikasi spreadsheet seperti Microsoft Excel atau LibreOffice Calc.

Medan eksport merangkumi:

```text
Tarikh
Jenis
Jumlah
Catatan
Catatan Tambahan
```

## Privasi

Versi offline ini tidak memerlukan akaun, server atau API untuk menyimpan transaksi. Data aplikasi berada dalam storage browser pengguna sehingga pengguna memadamkannya atau memulihkan data lain.

## Had Semasa

- Data tidak diselaraskan secara automatik antara peranti.
- Data tidak disimpan ke cloud.
- `localStorage` bergantung pada browser dan origin yang digunakan.
- Backup perlu dilakukan sendiri.
- Aplikasi ini ialah alat rekod kewangan peribadi, bukan sistem perakaunan penuh.

## Idea Penambahbaikan

Beberapa ciri yang boleh ditambah pada versi akan datang:

- Filter Bulanan / Tahunan / Keseluruhan
- Bajet bulanan mengikut kategori
- Sasaran simpanan
- Perbandingan bulan-ke-bulan
- Import CSV
- PWA untuk pengalaman pemasangan seperti aplikasi
- IndexedDB untuk penyimpanan tempatan yang lebih besar
- Pilihan sync Google Sheets / OneDrive
- Dark mode
- PIN atau perlindungan akses tempatan

## Screenshot

Tambahkan screenshot aplikasi ke folder projek, contohnya:

```text
assets/
└── dashboard.png
```

Kemudian masukkan ke README:

```markdown
![Dashboard Rekod Aliran Tunai](assets/dashboard.png)
```

## Menjalankan Secara Offline

Selepas fail HTML berada pada komputer:

```text
Double-click rekod-aliran-tunai-offline.html
```

atau:

```text
Right Click → Open with → Google Chrome / Microsoft Edge
```

Aplikasi boleh digunakan tanpa backend.

## Keselamatan Data

Untuk mengurangkan risiko kehilangan rekod:

1. Buat **Backup JSON** secara berkala.
2. Simpan backup di lokasi berasingan seperti external drive atau cloud storage.
3. Jangan bergantung pada `localStorage` sebagai satu-satunya salinan rekod penting.

## Lesen

Anda boleh menambah lesen pilihan anda, contohnya MIT License, jika repository ini ingin dikongsi sebagai projek open-source.

---

Dibangunkan sebagai projek pembelajaran **HTML, CSS, Vanilla JavaScript dan browser-based offline storage**.
